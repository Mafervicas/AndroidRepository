package com.example.act8_agendatel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //Inicializamos permiso de teléfono
    private static final int PERMISSION_PHONE_REQUEST_CODE = 102;

    //Generamos Boton que abre la llamada
    private Button openPhoneButton;
    private Button openPhoneButton2;
    private Button openPhoneButton3;
    private Button openPhoneButton4;
    private Button openPhoneButton5;
    private Button openPhoneButton6;

    //Para el celular
    private String phoneSelected;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Encontramos el botón por id
        openPhoneButton = findViewById(R.id.btn_open_phone);
        openPhoneButton.setOnClickListener(this);
        openPhoneButton2 = findViewById(R.id.btn_open_phone2);
        openPhoneButton2.setOnClickListener(this);
        openPhoneButton3 = findViewById(R.id.btn_open_phone3);
        openPhoneButton3.setOnClickListener(this);
        openPhoneButton4 = findViewById(R.id.btn_open_phone4);
        openPhoneButton4.setOnClickListener(this);
        openPhoneButton5 = findViewById(R.id.btn_open_phone5);
        openPhoneButton5.setOnClickListener(this);
        openPhoneButton6 = findViewById(R.id.btn_open_phone6);
        openPhoneButton6.setOnClickListener(this);
    }


    //Dependiendo el botón pone el teléfono
    @Override
    public void onClick(View v) {
        if (v.equals(openPhoneButton)) {
            openPhone("tel:5538294882");}
        else if (v.equals(openPhoneButton2)){
            openPhone("tel:5528611392"); }
        else if (v.equals(openPhoneButton3)){
            openPhone("tel:5549021445");}
        else if (v.equals(openPhoneButton4)){
            openPhone("tel:5573667921");}
        else if (v.equals(openPhoneButton5)){
            openPhone("tel:5613509395");}
        else if (v.equals(openPhoneButton6)){
            openPhone("tel:5545962766");}
    }

    //Permisos para poder hacer la llamada
    private void openPhone(String phone) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            // La aplicación sí tiene permisos para realizar esta acción.
            Uri uri = Uri.parse(phone);
            Intent intent = new Intent(Intent.ACTION_CALL);
            intent.setData(uri);
            startActivity(intent);
        } else {
            phoneSelected = phone;
            // La aplicación no tiene permisos para realizar esta acción y hay que solicitar el permiso al usuario.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_PHONE_REQUEST_CODE);
        }
    }

    //Aquí es como un filtro con los permisos
    //Si se aceptó el permiso, se apre el teléfono
    //Si no, manda mensaje de que no existen los permisos
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_PHONE_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openPhone(phoneSelected);
            } else {
                Toast.makeText(this, "La aplicación no tiene acceso al teléfono", Toast.LENGTH_SHORT).show();
            }
        }
    }
}