package com.example.act15_conversiones;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText txtUnidad1;
    private EditText txtUnidad2;
    private EditText txtUnidad3;
    private EditText txtUnidad4;
    private EditText txtUnidad5;
    private EditText txtUnidad6;
    private Button btn1to2;
    private Button btn2to1;
    private Button btn3to4;
    private Button btn4to3;
    private Button btn5to6;
    private Button btn6to5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //Ocultamos la barra de default

        //Traemos por id
        txtUnidad1 = findViewById(R.id.txt_unidad_1);
        txtUnidad2 = findViewById(R.id.txt_unidad_2);
        txtUnidad3 = findViewById(R.id.txt_unidad_3);
        txtUnidad4 = findViewById(R.id.txt_unidad_4);
        txtUnidad5 = findViewById(R.id.txt_unidad_5);
        txtUnidad6 = findViewById(R.id.txt_unidad_6);

        //Decimos que hará cada botón
        btn1to2 = findViewById(R.id.btn_1_to_2);
        btn1to2.setOnClickListener(this);
        btn2to1 = findViewById(R.id.btn_2_to_1);
        btn2to1.setOnClickListener(this);
        btn3to4 = findViewById(R.id.btn_3_to_4);
        btn3to4.setOnClickListener(this);
        btn4to3 = findViewById(R.id.btn_4_to_3);
        btn4to3.setOnClickListener(this);
        btn5to6 = findViewById(R.id.btn_5_to_6);
        btn5to6.setOnClickListener(this);
        btn6to5 = findViewById(R.id.btn_6_to_5);
        btn6to5.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.equals(btn1to2)) {
            convert1to2();
        } else if (view.equals(btn2to1)) {
            convert2to1();
        } else if (view.equals(btn3to4)) {
            convert3to4();
        } else if (view.equals(btn4to3)) {
            convert4to3();
        } else if (view.equals(btn5to6)) {
            convert5to6();
        } else if (view.equals(btn6to5)) {
            convert6to5();
        }
    }

    private void convert1to2() {
        // Leer la cantidad de celsius que se quiere convertir.
        double celsius = Double.parseDouble(txtUnidad1.getText().toString());
        // Convertir celsius a farenheit.
        double farenheit = (celsius * 1.8) + 32;
        // Desplegar el resultado de la conversión.
        txtUnidad2.setText(String.valueOf(farenheit));
    }

    private void convert2to1() {
        // Leer la cantidad de farenheit que se quiere convertir.
        double farenheit = Double.parseDouble(txtUnidad2.getText().toString());
        // Convertir celsius a farenheit.
        double celsius = ((farenheit - 32)* 5)/9;
        // Desplegar el resultado de la conversión.
        txtUnidad1.setText(String.valueOf(celsius));
    }

    private void convert3to4() {
        // Leer la cantidad de cm que se requiere convertir
        double cm = Double.parseDouble(txtUnidad3.getText().toString());
        // Convertir cm a Metros
        double m = (cm / 100) ;
        // Desplegar el resultado de la conversión.
        txtUnidad4.setText(String.valueOf(m));
    }

    private void convert4to3() {
        // Leer la cantidad de m que se requiere convertir
        double m = Double.parseDouble(txtUnidad4.getText().toString());
        // Convertir cm a Metros
        double cm = (m * 100) ;
        // Desplegar el resultado de la conversión.
        txtUnidad3.setText(String.valueOf(cm));
    }

    private void convert5to6() {
        // Leer la cantidad de Mb que se requiere convertir
        double Mb = Double.parseDouble(txtUnidad5.getText().toString());
        // Convertir cm a Metros
        double Kb = (Mb * 1000) ;
        // Desplegar el resultado de la conversión.
        txtUnidad6.setText(String.valueOf(Kb));
    }

    private void convert6to5() {
        // Leer la cantidad de Mb que se requiere convertir
        double Kb = Double.parseDouble(txtUnidad6.getText().toString());
        // Convertir cm a Metros
        double Mb = (Kb / 1000) ;
        // Desplegar el resultado de la conversión.
        txtUnidad5.setText(String.valueOf(Mb));
    }

}