//Mafer Villegas Casco
//2817368

package com.example.act6_consultas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    //Damos de alta el botón que cambiará entre pantallas
    Button boton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //Ocultamos la barra de default

        //Traemos el botón por id
        boton= (Button) findViewById(R.id.BotonInicio);

        //Le diremos qué pasará cuando el usuario clickee
        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this, SegundaPantalla.class);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
    });
    }
}