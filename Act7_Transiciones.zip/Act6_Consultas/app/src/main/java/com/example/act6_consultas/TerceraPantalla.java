package com.example.act6_consultas;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class TerceraPantalla extends AppCompatActivity {

    //Declaramos variables

    ImageView imageView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tercera_pantalla);

        //Encontramos por id las cosas
        imageView=(ImageView) findViewById(R.id.imageView);
        button= (Button) findViewById(R.id.gracias);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((TransitionDrawable) imageView.getDrawable()).startTransition(10000);
            }
        });
    }
}