package com.example.act6_consultas;

//Importamos librerias
import android.app.DatePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

//Dentro de la clase implementamos los métodos que nos permitan usar el spinner, el datepicker, el timepicker y para respuesta del botón
public class SegundaPantalla extends AppCompatActivity implements AdapterView.OnItemSelectedListener, TimePicker.OnTimeChangedListener, View.OnClickListener {

    //Inicializamos las variables
    private static final String TAG = "MainActivity";
    private final Calendar calendar = Calendar.getInstance();
    Button boton2;
    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Spinner spinner;
    private String selectedOption = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_pantalla);

        //Boton para Toast
        boton2= (Button) findViewById(R.id.calcula);
        //Le diremos qué pasará cuando el usuario clickee
        boton2.setOnClickListener(this);

        // Time picker
        TimePicker timePicker = findViewById(R.id.time_picker);
        timePicker.setOnTimeChangedListener(this);

        //Spinner
        spinner = findViewById(R.id.spinner);
        //Lo conectamos con el xml de strings donde está nuestro array/lista
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.padecimiento, R.layout.support_simple_spinner_dropdown_item);
        //Ponemos un set del spinner a un adaptador
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


        //Calendario textView
            //Lo encontramos y le decimos qué tiene que haccer
            mDisplayDate = (TextView) findViewById(R.id.tvFecha);
            mDisplayDate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //Con esto vamos a empezar con el día de hoy
                    Calendar cal = Calendar.getInstance();
                    int year = cal.get(Calendar.YEAR);
                    int month = cal.get(Calendar.MONTH);
                    int day = cal.get(Calendar.DAY_OF_MONTH);

                    //Esto es para el estilo y el tema
                    DatePickerDialog dialog = new DatePickerDialog(
                            SegundaPantalla.this,
                            android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                            mDateSetListener,
                            year,month,day);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.show();
                }
            });

            //Con esto le ponemos el formato
            mDateSetListener = new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                    month = month + 1;
                    Log.d(TAG, "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                    String date = month + "/" + day + "/" + year;
                    mDisplayDate.setText(date);
                }
            };

    }


    //Métodos para el tiempo
    @Override
    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
        //Se fija la hora y los minutos
        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
        calendar.set(Calendar.MINUTE, minute);
    }


    //Métodos Toast en Botón
    @Override
    public void onClick(View v) {
        DateFormat dateFormat = SimpleDateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);
        String date  = dateFormat.format(calendar.getTime());
        Toast.makeText(SegundaPantalla.this, "Cita agendada para: "+ date + ". Causa: "+ selectedOption + ". Gracias", Toast.LENGTH_LONG).show();
    }


    //Métodos de Spinner
    //Algo seleccionado
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent.equals(spinner)) {
            selectedOption = parent.getItemAtPosition(position).toString();
        }
    }

    //Nada seleccionado
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        if (parent.equals(spinner)) {
            selectedOption = "";
        }
    }
}


