package com.example.act4fragmentos;

public interface ComunicaMenu {
    public void menu(int botonSeleccionado);
}