package com.example.act14_sensores;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    //Inicializamoss variables
    private TextView tvTemperatura, tvProximidad;
    private SensorManager sensorManager;
    private Sensor tempSensor;
    private Sensor proxSensor;
    private Boolean SensorTempDisponible;
    private Boolean SensorProxDisponible;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide(); //Ocultamos la barra de default

        //Unimos por ID
        tvTemperatura = findViewById(R.id.tvTemperature);
        tvProximidad = findViewById(R.id.tvProximity);

        //Creamos el objeto de sensor
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        //Condicionando para saber disponibilidad de sensor temperatura
        if(sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)!=null){
            tempSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE);
            SensorTempDisponible = true;
        }else {
            tvTemperatura.setText("El sensor de temperatura no está disponible");
            SensorTempDisponible = false;
        }
        //Condicionando para saber disponibilidad de sensor proximidad
        if(sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)!=null){
            proxSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
            SensorProxDisponible = true;
        }else {
            tvProximidad.setText("El sensor de temperatura no está disponible");
            SensorProxDisponible = false;
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_AMBIENT_TEMPERATURE) {
            tvTemperatura.setText(event.values[0] + " °C");
        }
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            tvProximidad.setText(event.values[0] + " cm");
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        //Checar nuevamente si está disponible el sensor temperatura
        if(SensorTempDisponible){
            sensorManager.registerListener(this, tempSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
        //Checar nuevamente si está disponible el sensor Proximidad
        if(SensorProxDisponible){
            sensorManager.registerListener(this, proxSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }

    }
    @Override
    protected void onPause() {
        super.onPause();
        if(SensorTempDisponible){
            sensorManager.unregisterListener(this);
        }
        if(SensorProxDisponible){
            sensorManager.unregisterListener(this);
        }
    }
}