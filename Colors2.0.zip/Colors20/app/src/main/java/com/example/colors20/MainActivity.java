package com.example.colors20;


//Importamos primero todas las librerías necesarias
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


//Agregamos que utilizaremos el detector de gestos
public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

    //Agregaremos las variables
    View view;        //Esto es para los métodos como entrada
    Button b;         //Aquí para el botón que aparecerá el arcoíris
    ImageView img;    //Esta es para la imagen

    //Declaramos para los gestos y el texto cambiante
    private TextView mTextView;
    private GestureDetector gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Para poner el background y traiga el textView
        view = this.getWindow().getDecorView();
        view.setBackgroundResource(R.color.Red);
        mTextView = (TextView) findViewById(R.id.myTextView);

        //Creas los gestos
        this.gestureDetector = new GestureDetector(this, this);
        gestureDetector.setOnDoubleTapListener(this);

        //Imagen
        b = (Button) findViewById(R.id.button12);
        img = (ImageView) findViewById(R.id.imageView4);
        b.setOnClickListener(view -> img.setImageResource(R.mipmap.arcoiris));

    }

    //Las próximas líneas de código son para que con el click se mande llamar el método
    //Y se genere el cambio de color en el background
    public void YellowColor(View v){
        view.setBackgroundResource(R.color.Yellow); mTextView.setText("Yellow");
    }
    public void RedColor(View v){
        view.setBackgroundResource(R.color.Red);mTextView.setText("Hello World!");
    }
    public void BlueColor(View v){
        view.setBackgroundResource(R.color.Blue); mTextView.setText("Blue");
    }
    public void GreenColor(View v){
        view.setBackgroundResource(R.color.Green); mTextView.setText("Green");
    }
    public void PurpleColor(View v){
        view.setBackgroundResource(R.color.Purple); mTextView.setText("Purple");
    }
    public void BlackColor(View v){
        view.setBackgroundResource(R.color.Black); mTextView.setText("Black");
    }
    public void WhiteColor(View v){
        view.setBackgroundResource(R.color.White); mTextView.setText("White");;
    }

    //Esto es para que por cada TouchEvent, se tenga como tal el evento
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    //Para cada gesto ponemos un color diferente

    //Con un tap se pondrá azúl
    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        mTextView.setText("Blue");
        view.setBackgroundResource(R.color.Blue);
        return false;
    }


    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        mTextView.setText("Yellow");
        view.setBackgroundResource(R.color.Yellow);
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        mTextView.setText("Black");
        view.setBackgroundResource(R.color.Black);
        return false;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        mTextView.setText("Green");
        view.setBackgroundResource(R.color.Green);
        return false;
    }

    //ShowPress será AguaMarina
    @Override
    public void onShowPress(MotionEvent motionEvent) {
        mTextView.setText("AguaMarina");
        view.setBackgroundResource(R.color.AquaMarine);

    }

    //Con un tap en la parte de arriba se pondrá blanco
    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        mTextView.setText("White");
        view.setBackgroundResource(R.color.White);
        return false;
    }

    //Cuando se haga un scroll, se pondrá morada la pantalla
    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        mTextView.setText("Purple");
        view.setBackgroundResource(R.color.Purple);
        return false;
    }

    //Cuando se presione por mucho tiempo se pondrá rosa
    @Override
    public void onLongPress(MotionEvent motionEvent) {
        mTextView.setText("Pink");
        view.setBackgroundResource(R.color.Pink);


    }

    //Con un fling, será naranja
    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        mTextView.setText("Orange");
        view.setBackgroundResource(R.color.Orange);
        return false;
    }
}