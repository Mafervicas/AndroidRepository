package com.example.act12_mosaico;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {


    //Inicializamos variables
    ImageView imageView1,imageView2,imageView3,imageView4,imageView5,imageView6,imageView7,imageView8,imageView9;
    Button btOpen;
    int n=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Encontrar by ID
        imageView1 = findViewById(R.id.imageView1);
        imageView2 = findViewById(R.id.imageView2);
        imageView3 = findViewById(R.id.imageView3);
        imageView4 = findViewById(R.id.imageView4);
        imageView5 = findViewById(R.id.imageView5);
        imageView6 = findViewById(R.id.imageView6);
        imageView7 = findViewById(R.id.imageView7);
        imageView8 = findViewById(R.id.imageView8);
        imageView9 = findViewById(R.id.imageView9);
        btOpen = findViewById(R.id.btOpen);

        //Request para el permiso de uso de la Cámara
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{
                            Manifest.permission.CAMERA
                    },
                    100);
        }

        //Para cuando se de click al botón
        btOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Para abrir la Cámara
                Intent intent = new Intent (MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 100);
            }
        });

    }

    @SuppressLint("MissingSuperCall")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        n++;
        if (requestCode == 100) {

            if(n==1) {
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView1
                imageView1.setImageBitmap(captureImage);
            }
            else if (n==2){
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 2
                imageView2.setImageBitmap(captureImage);
            }
            else if (n==3){
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 3
                imageView3.setImageBitmap(captureImage);
            }
            else if (n==4) {
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 4
                imageView4.setImageBitmap(captureImage);
            }
            else if (n==5){
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 5
                imageView5.setImageBitmap(captureImage);
            }
            else if (n==6){
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 6
                imageView6.setImageBitmap(captureImage);
            }
            else if (n==7){
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 7
                imageView7.setImageBitmap(captureImage);
            }
            else if (n==8){
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 8
                imageView8.setImageBitmap(captureImage);
            }
            else {
                //Captura la Imagen
                Bitmap captureImage = (Bitmap) data.getExtras().get("data");
                //Se guarda la Imagen en el ImageView 9
                imageView9.setImageBitmap(captureImage);
                btOpen.setEnabled(false);
            }
        }
    }
}