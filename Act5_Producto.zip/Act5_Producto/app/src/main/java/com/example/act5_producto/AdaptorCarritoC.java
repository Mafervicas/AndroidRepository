package com.example.act5_producto;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AdaptorCarritoC extends RecyclerView.Adapter<AdaptorCarritoC.CtcasViewHolder> {
    //Declaramos variables
    Context context;
    List<Helado>carritoCompras;
    TextView Total;
    double total = 0;

    //Generamos Constructor


    public AdaptorCarritoC(Context context, List<Helado> carritoCompras, TextView Total) {
        this.context = context;
        this.carritoCompras = carritoCompras;
        this.Total = Total;

        //Creamos un for que recorra el array y devuelva el precio
        for (int i = 0 ; i < carritoCompras.size(); i ++){
            total = total+ Double.parseDouble(""+ carritoCompras.get(i).getPrecio());

        }
        //Le asignamos el valor
        Total.setText(""+total);
    }

    //Nos traemos everything
    @NonNull
    @Override
    public CtcasViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        @SuppressLint("InflateParams") View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_carrito_compras, null, false);
        return new AdaptorCarritoC.CtcasViewHolder(v);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final CtcasViewHolder ctcasViewHolder, final int i) {
        //Con este le ponemos al texto lo que obtenga en i
        ctcasViewHolder.nomCtca.setText(carritoCompras.get(i).getNomCtca());
        ctcasViewHolder.descripcion.setText(carritoCompras.get(i).getDescripcion());
        ctcasViewHolder.precio.setText(""+carritoCompras.get(i).getPrecio());


    }

    @Override
    public int getItemCount() {
        return carritoCompras.size();
    }

    public class CtcasViewHolder extends RecyclerView.ViewHolder {
        //Esto es igual para que funcione el recyclerview con los valores previamente definidos
        TextView nomCtca;
        TextView descripcion;
        TextView precio;

        public CtcasViewHolder(@NonNull  View itemView) {
            super(itemView);

            nomCtca = itemView.findViewById(R.id.nomCtca);
            descripcion = itemView.findViewById(R.id.descripcion);
            precio = itemView.findViewById(R.id.precio);

        }
    }

}
