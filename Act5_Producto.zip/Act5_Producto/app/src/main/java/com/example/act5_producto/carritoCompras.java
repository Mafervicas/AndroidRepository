package com.example.act5_producto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class carritoCompras extends AppCompatActivity {

    //Inicializamos las variables a utilizar
    List<Helado> carritoCompras;
    AdaptorCarritoC adaptador;
    RecyclerView rvListaCarrito;
    TextView Total;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito_compras);
        getSupportActionBar().hide(); //Oculto la ActionBar


        //Me traigo el carrito
        carritoCompras = (List<Helado>) getIntent().getSerializableExtra("CarritoCompras");


        //Guardamos dentro de rvLista la lista que se encuentra en el archivo xml
        //Al igual que el Total
        rvListaCarrito = findViewById(R.id. rvListaCarrito );
        rvListaCarrito.setLayoutManager(new GridLayoutManager(carritoCompras.this,1 ));
        Total= findViewById(R.id.Total);

        adaptador= new AdaptorCarritoC(carritoCompras.this, carritoCompras, Total);
        //Le doy un set al adaptador que creamos
        rvListaCarrito.setAdapter(adaptador);

    }
}