package com.example.act5_producto;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.Serializable;
import java.util.List;

public class AdaptorCtcas extends RecyclerView.Adapter<AdaptorCtcas.CtcasViewHolder> {
    //Declaramos variables
    Context context;
    TextView cantidad;
    Button verCarrito;
    List<Helado> listaCtcas;
    List<Helado> carritoCompras;

    //Generamos Constructor
    public AdaptorCtcas(Context context, TextView cantidad, Button verCarrito, List<Helado> listaCtcas, List<Helado> carritoCompras) {
        this.context = context;
        this.cantidad = cantidad;
        this.verCarrito = verCarrito;
        this.listaCtcas = listaCtcas;
        this.carritoCompras = carritoCompras;
    }


    //Nos traemos everything
    @NonNull
    @Override
    public CtcasViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        @SuppressLint("InflateParams") View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_caracteristicas, null, false);
        return new AdaptorCtcas.CtcasViewHolder(v);
    }

    @SuppressLint("SetTextI18n")
    @Override
    //Dependiendo del valor de i con el id se obtendrán los nombres, descripciones y precios de los toppings
    public void onBindViewHolder(@NonNull final CtcasViewHolder ctcasViewHolder,final int i) {
        ctcasViewHolder.nomCtca.setText(listaCtcas.get(i).getNomCtca());
        ctcasViewHolder.descripcion.setText(listaCtcas.get(i).getDescripcion());
        ctcasViewHolder.precio.setText(""+listaCtcas.get(i).getPrecio());

        //Dependiendo de si el checkbox está clickeado se sumará uno al total
        //Si no se le restará
        ctcasViewHolder.Carro.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(ctcasViewHolder.Carro.isChecked()){
                cantidad.setText(""+(Integer.parseInt(cantidad.getText().toString().trim())+1));
                carritoCompras.add(listaCtcas.get(i));
            } else if (!ctcasViewHolder.Carro.isChecked()){
                cantidad.setText(""+(Integer.parseInt(cantidad.getText().toString().trim())-1));
                carritoCompras.remove(listaCtcas.get(i));
            }

        });

        //Con este navegaremos a la página de las compras finales y totales
        verCarrito.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, carritoCompras.class);
                intent.putExtra("CarritoCompras", (Serializable) carritoCompras);
                context.startActivity(intent);
            }
        });

    }

    @Override
    //Con este retornamos el tamaño de la lista conteada
    public int getItemCount() {
        return listaCtcas.size();
    }


    public class CtcasViewHolder extends RecyclerView.ViewHolder {
        //Esto es lo que está dentro del Recycler
        //Desde los atributos
        TextView nomCtca;
        TextView descripcion;
        TextView precio;
        CheckBox Carro;

        public CtcasViewHolder(@NonNull  View itemView) {
            super(itemView);
            //Hasta el linkeo con su respectivo id

            nomCtca = itemView.findViewById(R.id.nomCtca);
            descripcion = itemView.findViewById(R.id.descripcion);
            precio = itemView.findViewById(R.id.precio);
            Carro = itemView.findViewById(R.id.Carro);
        }
    }

}
