//Mafer Villegas Casco
//13/09/2021


package com.example.act5_producto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //Me traigo los elementos inicializándolos
    TextView cantidad;
    Button verCarrito;
    RecyclerView rvListaCtcas;
    AdaptorCtcas adaptador;

    //Creo las listas que se llenarán con los toppings de los helados
    List<Helado> listaCtcas = new ArrayList<>();
    List<Helado> carritoCompras = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //Ocultamos la barra de default

        //Hacemos que se conecten mediante el id
        cantidad = findViewById(R.id.cantidad);
        verCarrito = findViewById(R.id.verCarrito);
        rvListaCtcas = findViewById(R.id.rvListaCtcas);
        rvListaCtcas.setLayoutManager(new GridLayoutManager(MainActivity.this, 1));

        //Con esto creamos objetos que vendrán siendo los toppings
        listaCtcas.add(new Helado( "1", "Chispas", "Agrégale chispitas de chocolate", 5.00));
        listaCtcas.add(new Helado( "2", "Galleta Oreo", "Las favoritas de la casa", 20.00));
        listaCtcas.add(new Helado( "3", "Granola", "Artesanal y baja en calorias", 10.00));
        listaCtcas.add(new Helado( "4", "Amaranto", "La vieja confiable", 5.50));
        listaCtcas.add(new Helado( "5", "Fruta", "De temporada", 20));
        listaCtcas.add(new Helado( "6", "Cajeta", "Usamos Cajeta Coronado", 11.20));
        listaCtcas.add(new Helado( "7", "Chocolate Líquido", "Se derrite cuando se enfría", 11.20));
        listaCtcas.add(new Helado( "8", "Galleta Maria", "Las mejores", 13.20));
        listaCtcas.add(new Helado( "9", "Arándanos", "Enchilados con limón", 14.50));
        listaCtcas.add(new Helado( "10", "Coco rallado", "Para darle un sabor tropical", 8.50));


        //Con esto llamaremos a la cals Adaptador para que jale la información
        adaptador = new AdaptorCtcas(MainActivity.this,cantidad,verCarrito,listaCtcas, carritoCompras);
        rvListaCtcas.setAdapter(adaptador);

    }
}