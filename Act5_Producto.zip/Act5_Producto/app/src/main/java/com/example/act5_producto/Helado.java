package com.example.act5_producto;

import java.io.Serializable;

public class Helado implements Serializable {

    //Ponemos los atributos que tendrán las características del helado
    String idCtca;
    String nomCtca;
    String descripcion;
    double precio;

    //Creamos un constructor para darles valor y poder utilizarlos después con nuestros valores
    public Helado(String idCtca, String nomCtca, String descripcion, double precio) {
        this.idCtca = idCtca;
        this.nomCtca = nomCtca;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    //Generamos Getters & Setters aunque no sean privates

    public String getIdCtca() {
        return idCtca;
    }

    public void setIdCtca(String idCtca) {
        this.idCtca = idCtca;
    }

    public String getNomCtca() {
        return nomCtca;
    }

    public void setNomCtca(String nomCtca) {
        this.nomCtca = nomCtca;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
