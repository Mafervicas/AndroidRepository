package com.example.act9_sms2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    //Primero declaramos todas las variables que utilizaremos
    private static final int SMS_PERMISSIONS_REQUEST = 100;
    private static final int SMS_SENT_REQUEST = 200;
    private static final int SMS_DELIVER_REQUEST = 201;
    private static final String SENT_ACTION = "android.provider.Telephony.SMS_SENT";
    private static final String DELIVER_ACTION = "android.provider.Telephony.SMS_RECEIVED";

    // Colocamos el ID del emulador.
    private static final String EMULATOR_PHONE_NUMBER = "5554";

    //Declaramos el edittext que teníamos y el textview
    private EditText mensajeSMS;
    private TextView tvLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide(); //Ocultamos la barra de default

        //Encontramos por ID los componentes y los guardamos en una variable
        Button btnSendSMS = findViewById(R.id.btnMandarSMS);
        tvLog = findViewById(R.id.tvLog);
        mensajeSMS = findViewById(R.id.etMandar);

        // Condicional sobre los permisos
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.SEND_SMS}, SMS_PERMISSIONS_REQUEST);
        }


        // Se instancia la clase SmsManager para enviar los sms.
        //Así como la de PendingIntent que los envia como tal
        //Y finalmente lo notificamos y registramos para recibirlo
        final SmsManager smsManager = SmsManager.getDefault();
        final PendingIntent sentIntent = PendingIntent.getBroadcast(MainActivity.this, SMS_SENT_REQUEST, new Intent(SENT_ACTION), 0);
        final PendingIntent deliveryIntent = PendingIntent.getBroadcast(MainActivity.this, SMS_DELIVER_REQUEST, new Intent(DELIVER_ACTION), 0);
        registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // Con esto lo que hacemos es crear un array que vaya guardando lo que está dentro del mensaje
                //Para después mandarlo como un toast
                if (intent.getAction().equals(DELIVER_ACTION)) {
                    // Leer el contenido SMS
                    Bundle bundle = intent.getExtras();
                    SmsMessage[] messages;
                    String str="";

                    if (bundle != null){
                        Object[] pdus = (Object[]) bundle.get("pdus");
                        messages = new SmsMessage[pdus != null ? pdus.length : 0];
                        for(int i=0; i<messages.length; i++){
                            messages[i] = SmsMessage.createFromPdu((byte[]) (pdus != null ? pdus[i] : null));
                            str += messages[i].getOriginatingAddress();
                            str += ": ";
                            str += messages[i].getMessageBody();
                            str += "\n";
                        }

                        //Para mostrar el mensaje como toast
                        Toast.makeText(context, str, Toast.LENGTH_LONG).show();
                }}
            }
        }, new IntentFilter(DELIVER_ACTION));

        //Aquí decimos que se hará cuando se de un click
        btnSendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Jala el texto y lo convierte a string del sms dado
                //Y lo envia con la clase SMS Manager
                String sms = mensajeSMS.getText().toString();
                smsManager.sendTextMessage(EMULATOR_PHONE_NUMBER, null, sms, sentIntent, deliveryIntent);
            }
        });
    }

    // Este únicamente es para el registro de los permisos
    //Y que muestre en el text view si hay o no hay accesos la primera vez que se dan
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSIONS_REQUEST
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
                && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
            tvLog.setText(getString(R.string.PermisosDados));
        } else {
            tvLog.setText(getString(R.string.PermisosDenegados));
        }
    }

}